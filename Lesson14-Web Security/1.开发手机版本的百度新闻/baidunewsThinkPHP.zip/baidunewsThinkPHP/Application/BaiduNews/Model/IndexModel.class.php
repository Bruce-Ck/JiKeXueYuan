<?php 
namespace BaiduNews\Model;
use Think\Model;
class IndexModel extends Model{
}