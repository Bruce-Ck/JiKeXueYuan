<?php
return array(
	//'配置项'=>'配置值'
	// 'DEFAULT_V_LAYER'       =>  'View', // 设置默认的视图层名称

);