<?php 
namespace Login\Model;
use Think\Model;
class LoginModel extends Model{
	//table前缀为空
	// protected $tablePrefix = '';
}